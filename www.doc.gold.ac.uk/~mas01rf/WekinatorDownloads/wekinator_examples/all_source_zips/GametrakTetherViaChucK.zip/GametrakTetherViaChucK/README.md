This will work best if you run it on command line, not in miniAudicle (requires that you install chuck first!). You may have to change the device number (see comment in code).
