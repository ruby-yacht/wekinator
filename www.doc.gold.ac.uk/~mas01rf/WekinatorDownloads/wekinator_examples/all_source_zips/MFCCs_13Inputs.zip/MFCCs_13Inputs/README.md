To build:

1. Install the following addons: 
ofxOsc
ofxMaxim (from https://github.com/micknoise/Maximilian; this is great for all sorts of audio processing and synthesis)

2. Create a new openFrameworks project using the project generator (or the New Project wizard in QT Creator), selecting both these addons.

3. Replace the contents of the src/ file in your new project with these three files.

4. Put arial.ttf in your project bin/data/ folder

5. Build and have fun!

