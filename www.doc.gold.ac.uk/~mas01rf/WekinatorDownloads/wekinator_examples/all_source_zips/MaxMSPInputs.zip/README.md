There are other Max/MSP examples in Arduino and AudioInput categories.

