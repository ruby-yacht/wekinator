## Wekinator browser mouse coordinates example
Train Wekinator how to recognize shape you draw with the mouse! Just press the button and draw a shape. Once released (if you have an OSC server running) it will send a blob of normalized, downsampled data over web sockets.
To run live reload server:  
```shell
npm install
npm run start
```
To export bundle and uglify Javascript:  
```shell
npm install
npm run build
```
