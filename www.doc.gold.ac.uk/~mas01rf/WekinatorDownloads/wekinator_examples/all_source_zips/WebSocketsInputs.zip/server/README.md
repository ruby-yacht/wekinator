### Server script for sending OSC
This is written to work with Wekinator and is not tested with anything else but you can send OSC data pretty much anywhere. To run:  
```shell
npm install
node server.js
```
Requires a recent node.js version that supports ES6.
