## ConvnetOSC

Sends Convnet activations as a 4096-bit input vector over OSC.

by default, sends to localhost, address="/wek/inputs", port 6448. press spacebar to toggle sending on/off.

make sure `image-net-2012.sqlite3` is inside the data folder. 
