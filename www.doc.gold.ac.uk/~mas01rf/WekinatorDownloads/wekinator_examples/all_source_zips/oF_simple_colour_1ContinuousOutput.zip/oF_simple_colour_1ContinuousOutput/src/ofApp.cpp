#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){
    backgroundColor.r=255;
    backgroundColor.g=0;
    backgroundColor.b=0;
    ofSetBackgroundColor(backgroundColor);
    
    //Start listening for OSC messages
    receiver.setup(PORT);
}

//--------------------------------------------------------------
void ofApp::update(){

    
    //Receive any incoming OSC messages
    while(receiver.hasWaitingMessages()){
        // get the next message
        ofxOscMessage m;
        receiver.getNextMessage(&m);
        
        // If it's the message we're expecting from Wekinator:
        if(m.getAddress() == "/wek/outputs"){
            int backgroundHue = m.getArgAsFloat(0) * 255; //Use first float in OSC message for our hue, mapping 0-1 to 0-255
            backgroundColor.setHue(backgroundHue);
        } else{
            // unrecognized message: display on the bottom of the screen
            string msgString;
            msgString = m.getAddress();
            msgString += ":";
            for(size_t i = 0; i < m.getNumArgs(); i++){
                
                // get the argument type
                msgString += " ";
                msgString += m.getArgTypeName(i);
                msgString += ":";
                
                // display the argument - make sure we get the right type
                if(m.getArgType(i) == OFXOSC_TYPE_INT32){
                    msgString += ofToString(m.getArgAsInt32(i));
                }
                else if(m.getArgType(i) == OFXOSC_TYPE_FLOAT){
                    msgString += ofToString(m.getArgAsFloat(i));
                }
                else if(m.getArgType(i) == OFXOSC_TYPE_STRING){
                    msgString += m.getArgAsString(i);
                }
                else{
                    msgString += "unhandled argument type " + m.getArgTypeName(i);
                }
            }
            cout << "Unexpected message: " << msgString << endl;
        }
        
    }

}

//--------------------------------------------------------------
void ofApp::draw(){
    ofSetBackgroundColor(backgroundColor);
    
    stringstream ss;
    ss << "Receives 1 continuous output" << endl;
    ss << "Listens on port 12000" << endl;
    ofDrawBitmapString(ss.str().c_str(), 20, 20);
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){

}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}
