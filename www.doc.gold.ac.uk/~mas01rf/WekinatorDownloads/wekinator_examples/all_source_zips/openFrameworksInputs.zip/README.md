If you are working on Mac, you can put this directory into open frameworks apps/myapps/ 

If you are on Windows, or if you are on Mac and can't get it to work, make a new project using the project generator, and make sure to also include the ofOsc addon. Then replace the contents of that new project's src directory with the contents of this src directory.

Additional OpenFrameworks input examples can be found in the audio and video input categories.